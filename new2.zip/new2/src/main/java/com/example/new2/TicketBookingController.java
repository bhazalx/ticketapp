package com.example.new2;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/bookings")
public class TicketBookingController {

    private final TicketBookingRepository bookingRepository;

    @Autowired
    public TicketBookingController(TicketBookingRepository bookingRepository) {
        this.bookingRepository = bookingRepository;
    }

    @GetMapping
    public List<TicketBooking> getAllBookings() {
        return bookingRepository.findAll();
    }

    @PostMapping
    public TicketBooking addBooking(@RequestBody TicketBooking booking) {
        System.out.println("Received Booking: " + booking);
        return bookingRepository.save(booking);
    }

    @DeleteMapping
    public void deleteAllBookings() {
        bookingRepository.deleteAll();
    }
}

