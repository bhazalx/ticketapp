$(document).ready(function() {
    let bilettRegister = [];


    function visbilettRegister() {
        let ut = "<table><tr>" +
            "<th>Film</th><th>Antall</th><th>Fornavn</th><th>Etternavn</th><th>TelefonNr</th><th>Epost</th>" +
            "</tr>";
        for (let p of bilettRegister) {
            ut += "<tr>";
            ut += "<td>" + p.Film + "</td><td>" + p.Antall + "</td><td>" + p.Fornavn + "</td><td>" + p.Etternavn + "</td><td>" + p.TelefonNr + "</td><td>" + p.Epost + "</td>";
            ut += "</tr>";
        }
        ut += "</table>";
        $("#bilettRegister").html(ut);
    }


    function registrerBilett() {
        const Film = $("#Film").val();
        const Antall = $("#Antall").val();
        const Fornavn = $("#Fornavn").val();
        const Etternavn = $("#Etternavn").val();
        const TelefonNr = $("#TelefonNr").val();
        const Epost = $("#Epost").val();


        $(".error").text("");

        if (Film === "") {
            $("#p1").text("Du må velge en film!");
        } else if (Antall === "") {
            $("#p2").text("Du må velge mengden av biletter før du går videre!");
        } else if (Antall < 1) {
            $("#p2").text("Du må ha minst ett bilett!");
        } else if (Fornavn === "") {
            $("#p3").text("Navn feltet kan ikke være tomt!");
        } else if (Etternavn === "") {
            $("#p4").text("Etternavn feltet kan ikke være tomt!");
        } else if (TelefonNr === "") {
            $("#p5").text("Du må taste inn et mobil nummer for å gå videre!");
        } else if (isNaN(TelefonNr)) {
            $("#p3").text("Du må taste inn gyldig mobil nummer, feltet kan ikke fylles ut med tekst!");
        } else if (Epost === "") {
            $("#p6").text("Du må taste inn en epost adresse for å fullføre registrasjonen!");
        } else {
            const person = {
                Film: Film,
                Antall: parseInt(Antall),
                Fornavn: Fornavn,
                Etternavn: Etternavn,
                TelefonNr: TelefonNr,
                Epost: Epost
            };


            $.ajax({
                type: "POST",
                url: "/api/bookings",
                contentType: "application/json",
                data: JSON.stringify(person),
                success: function() {
                    bilettRegister.push(person);
                    visbilettRegister();

                    $("#Film, #Antall, #Fornavn, #Etternavn, #TelefonNr, #Epost").val("");
                },
                error: function(xhr, status, error) {
                    console.log("Error adding ticket:", error);
                }
            });
        }
    }

    function slettBiletter() {
        $.ajax({
            type: "DELETE",
            url: "/api/bookings",
            success: function() {
                bilettRegister = [];
                visbilettRegister();
            },
            error: function(xhr, status, error) {
                console.log("Error deleting tickets:", error);
            }
        });
    }

    $("#submitBtn").click(registrerBilett);
    $("#deleteBtn").click(slettBiletter);
});
